import requests
from bs4 import BeautifulSoup
import csv
import os 
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from scrape_subcollection import scrape_subcollection

url = 'https://crowd.loc.gov/campaigns/early-copyright/'

i=0
# Launch Chrome
options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--disable-gpu')
driver = webdriver.Chrome(options=options)

# Load the page
driver.get(url)

# Wait for the campaign cards to appear
wait = WebDriverWait(driver, 5)
campaign_cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '.concordia-object-card-row .concordia-object-card')))

# Extract the links from the campaign cards
collection_links = []
for card in campaign_cards:
    link = card.find_element_by_css_selector('a').get_attribute('href')
    collection_links.append(link)

# Close the browser
driver.quit()

# Set up a headless Chrome browser
options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--disable-gpu')
driver = webdriver.Chrome(options=options)

# Get the desktop directory path
desktop_path = os.path.expanduser("~/Desktop")
i=0
#remember I skiped labels and ephemera (LINK 7)
# Loop through each collection link and scrape the transcriptions
for link in collection_links[-1:]:
    i=i+1
    progress_collection=i/len(collection_links) *100
    print(f"{progress_collection} % collections done")
    # Get the URL of the collection
    collection_url = link

    # Make a request to the collection page
    collection_response = requests.get(collection_url)

    # Parse the HTML content with BeautifulSoup
    collection_soup = BeautifulSoup(collection_response.content, 'html.parser')

    # Find all the links to the subcollections in the collection
    subcollection_links = collection_soup.find_all('a', href=True)

    # Filter out the subcollection links
    subcollection_links = [link['href'] for link in subcollection_links if '/campaigns/' and '1860' and 'pages' in link['href'] and 'account' not in link['href']] 
    subcollection_links=[*set(subcollection_links)]
    for item in range(0,len(subcollection_links)):
        subcollection_links[item]='https://crowd.loc.gov'+subcollection_links[item]
    
    # Loop through each subcollection link and scrape the transcriptions
    for subcollection_link in subcollection_links:
        if i==1:
            
            scrape_subcollection(subcollection_link,8)
        else:
            scrape_subcollection(subcollection_link,1)
        
        
        
         
        
        
# Close the browser
driver.quit()
