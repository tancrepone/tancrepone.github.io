import requests
from bs4 import BeautifulSoup
import csv
import os 
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_subcollection(subcollection_url,start):
    desktop_path = os.path.expanduser("~/Desktop")
    # Launch Chrome
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    driver = webdriver.Chrome(options=options)
    # Make a request to the subcollection URL
    response = requests.get(subcollection_url)

    # Parse the HTML using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the nav element with class w-100
    nav = soup.find('nav', class_='w-100')

    # Find all the li elements with class page-item
    page_links = nav.find_all('li', class_='page-item')

    # Find the last page number
    last_page = int(page_links[-2].find('a').get('href').split('=')[-1])

    # Loop through each page and scrape the results
    for page in range(start, last_page + 1):
        page_url = f'{subcollection_url}&page={page}'

        progress = page / last_page * 100
        print(f"{progress} % of collection.")
        # Make a request to the page and parse the HTML content
        page_response = requests.get(page_url)
        page_soup = BeautifulSoup(page_response.content, 'html.parser')

        # Find all the links to the individual


        # Find all the links to the individual records on the page
        record_links = page_soup.find_all('a', class_='card-img-container')
        record_links = [link['href'] for link in record_links]

        # Loop through each record link and scrape the transcription
        for record_link in record_links:
            # Get the URL of the record
            record_url = 'https://crowd.loc.gov' + record_link
          
            try:
                # Load the record page and wait for the transcription to load
                driver.get(record_url)
                wait = WebDriverWait(driver, 5)
                transcription_div = wait.until(EC.presence_of_element_located((By.NAME, 'text')))
                transcription_text = transcription_div.text.strip()
        
                # Write the transcription to a CSV file on the desktop
                csv_path = os.path.join(desktop_path, 'transcriptions.csv')
                with open(csv_path, mode='a', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    writer.writerow([record_url, transcription_text])
            except Exception as e:
                # Handle the error
                print(f"Error scraping record {record_url}: {e}")
                continue
       